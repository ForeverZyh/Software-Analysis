#include<stdio.h>
float b[110][110],a[110];
int main()
{
    int n,i,j,x,y,k;
    n=100;

#pragma acc parallel loop
    for(i=0;i<n;i++) a[i]=i;

    for(i=0;i<n;i++) x=a[i];

#pragma acc parallel loop reduction(+:x)
    for(i=0;i<n;i++) x=x+a[i];

    for(i=0;i<n;i++) a[i]=i;
    y=i;

#pragma acc parallel loop
    for(i=0;i<n;i++) a[i]=a[i]+1;

    for(i=0;i<n;i++) a[i]=a[i+1];

    for(i=0;i<n;i++)
    {
        float sum;
		sum=0;
#pragma acc parallel loop reduction(+:sum)
        for(j=0;j<n;j++)
        {
            b[i][j]=a[j];
            sum=sum+b[i][j];
        }
#pragma acc parallel loop
        for(j=0;j<n;j++) a[j]=sum/100;
    }
	return 0;
}

int main()
{
	int x,y;
	x=1;
	y=2;
	if (x)
	{
		int y;
		x=y;
	}
	return 0;
}

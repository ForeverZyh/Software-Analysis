b[i][j]=a[j]
 sum=sum+b[i][j]
A[j ][ i] = 0.25 * ( Anew[j][i+1] + Anew[j][i-1]+ Anew[j-1][i] + Anew[j+1][i])
error = fmax( error, fabs(A[j][i] - Anew[j][i]))
i<n
i++
i!=x+1&&sf==s
sum+=2
i<<=1
int   a[1001]
	int a,b,c
  float __sdf
